# pandoc-restapi

The main purpose of this repository is to be used by my main website as a micro service.
Flask for server, bootstrap for front, heroku for hosting.

[demo](https://pandoc-api.herokuapp.com/)

